package com.example.degidn_test02;


import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.text.format.Time;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static android.content.Context.MODE_PRIVATE;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment implements NotesAdapter.OnRecyclerItemClick {

    private RecyclerView recyclerView;
    private NotesAdapter notesAdapter;
    private List<NotesModel> modelList;
    TextView txtchiso;
    String diachi;
    SharedPreferences sharedPreferences;
    int dieukhien=0;
    DatePicker datePicker;
    int day,month;

    public  static  ArrayList<String> head = new ArrayList<>();
    //    private String[] head = {"Video call to client team.",
//            "Video call to team lead.",
//            "Python practise.",
//            "Coding my app",
//            "Python practise.",
//            "Coding my app"};
    public  static  ArrayList<String> desc = new ArrayList<>();
    //    private String[] desc = {"This is some random data for showing the description in the layout.",
//            "This is some random data for showing the description in the layout.",
//            "This is some random data for showing the description in the layout.",
//            "This is some random data for showing the description in the layout.",
//            "This is some random data for showing the description in the layout.",
//            "This is some random data for showing the description in the layout."};
   public static ArrayList<String> time = new ArrayList<>();
//    private String[] time = {"11:15 am", "12:30 am", "2:30 pm", "4:00 pm", "2:30 pm", "4:00 pm"};

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        recyclerView = view.findViewById(R.id.recycler);
        txtchiso = getActivity().findViewById(R.id.idchiso);
        String diachi = txtchiso.getText().toString();

        getData();

        new Handler().postDelayed(new Runnable() {
            public void run() {
                getdieukhien();
                if(dieukhien==0) {
                getfirebasethannhiet(diachi);
                getfirebasethoigiant(diachi);
                    dieukhien=1;
                    savedieukhien(dieukhien);
                }
                else if (dieukhien==1)
                {
                    getDatatime();
                    Time today = new Time(Time.getCurrentTimezone());
                    today.setToNow();
                    //Toast.makeText(getActivity(),today.monthDay+"t",Toast.LENGTH_SHORT).show();
                    int ngay=today.monthDay;

                    int thang=today.month+1;
                    //    Toast.makeText(getActivity(),thang+"",Toast.LENGTH_SHORT).show();
                    //    getDatatime();
                    if(ngay!=day || thang!=month)
                    {
                        dieukhien=0;
                        saveDatatime(ngay,thang);
                    }
                    savedieukhien(dieukhien);
                }
                Toast.makeText(getActivity(),dieukhien+"thi",Toast.LENGTH_SHORT).show();
            }
        }, 500);




        new Handler().postDelayed(new Runnable() {
            public void run() {

                saveData();



                modelList = new ArrayList<>();
                for (int i = 0; i < desc.size(); i++)
                {
                    NotesModel notesModel = new NotesModel();
                    notesModel.setHead("Phòng chống covid!");
                    notesModel.setDesc("Thân nhiệt của bạn vào ngày này là:" + desc.get(i));
                    notesModel.setTime(time.get(i));
                    //if you want to use icons for different categories you can use the following line :
                    //notesModel.setView(PASS ICONS HERE LIKE WORK, PERSONAL, ETC);
                    modelList.add(notesModel);
                }

                notesAdapter = new NotesAdapter(modelList, getContext());
                recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
                recyclerView.setAdapter(notesAdapter);

                notesAdapter.setOnRecyclerItemClick(this);


            }
        }, 1000);

        return view;
    }

    @Override
    public void onClick(int pos) {
        Toast.makeText(getContext(), "Pos is : " + pos, Toast.LENGTH_SHORT).show();
    }


    private void getfirebasethannhiet(String diachi) {

        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        DatabaseReference myRef = database.child("Information/" + diachi + "/thannhiet");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String nd = dataSnapshot.getValue().toString();
              //  Toast.makeText(getActivity(),nd,Toast.LENGTH_SHORT).show();
                desc.add(nd);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }

        });
    }
    private void getfirebasethoigiant(String diachi) {

        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        DatabaseReference myRef = database.child("Information/" + diachi + "/thoigian");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String thoigian = dataSnapshot.getValue().toString();
                time.add(thoigian);
                // Toast.makeText(login.this,demcount+"heree",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }

        });
    }
    public void saveData(){

        TinyDB tinydb = new TinyDB(getActivity());
        tinydb.putListString("thannhiet", desc);
        tinydb.putListString("thoigian", time);


    }
    public void getData(){

        TinyDB tinydb = new TinyDB(getActivity());
        desc=tinydb.getListString("thannhiet");
        time=tinydb.getListString("thoigian");

    }
    public void saveDatatime(int ngay, int thang){

        TinyDB tinydb = new TinyDB(getActivity());
        tinydb.putInt("ngay", ngay);
        tinydb.putInt("thang", thang);


    }
    public void getDatatime(){

        TinyDB tinydb = new TinyDB(getActivity());
        day=tinydb.getInt("ngay");
        month=tinydb.getInt("thang");


    }
    public void savedieukhien(int dieukhien){

        TinyDB tinydb = new TinyDB(getActivity());
        tinydb.putInt("dieukhien", dieukhien);



    }
    public void getdieukhien(){

        TinyDB tinydb = new TinyDB(getActivity());
        dieukhien=tinydb.getInt("dieukhien");



    }



}
