package com.example.degidn_test02;

public class nhanvien {
        private String Hoten;
        private  String Id;
        private String Mathe;
        private  String Thannhiet;
        private  String Thoigian;

        public nhanvien(String hoten, String id, String mathe,String thannhiet, String thoigian) {
            Hoten = hoten;
            Id = id;
            Mathe = mathe;
            Thannhiet = thannhiet;
            Thoigian = thoigian;
        }

    public String getHoten() {
        return Hoten;
    }

    public void setHoten(String hoten) {
        Hoten = hoten;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getMathe() {
        return Mathe;
    }

    public void setMathe(String mathe) {
        Mathe = mathe;
    }

    public String getThannhiet() {
        return Thannhiet;
    }

    public void setThannhiet(String thannhiet) {
        Thannhiet = thannhiet;
    }

    public String getThoigian() {
        return Thoigian;
    }

    public void setThoigian(String thoigian) {
        Thoigian = thoigian;
    }
}
