package com.example.degidn_test02;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;



public class MainActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private View view;

    private TextView textView,txtname,txtid,txtchiso;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tabLayout = findViewById(R.id.tabLayout);
        view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.tab_background, null);
        textView = view.findViewById(R.id.tv1);
        imageView = view.findViewById(R.id.iv1);
        txtname=findViewById(R.id.txtname);
        txtid=findViewById(R.id.txtid);
        txtchiso=findViewById(R.id.idchiso);



        Intent intent=getIntent();
        int vitri=intent.getIntExtra("idnv",1);

        String chuoi=String.valueOf(vitri);
        txtchiso.setText(chuoi);
        loadnamefirebase(vitri);
        loadidfirebase(vitri);


        setCustomView(0, 1);
        setTextAndImageWithAnimation("HISTORY", R.drawable.history);
        handleFragment(new HomeFragment());

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {

                    case 1:
                        setCustomView(1, 0);
                        setTextAndImageWithAnimation("PROFILE", R.drawable.ic_categories);

                        handleFragment(new catalogFragment());

                        break;

                    default:
                        setCustomView(0, 1);
                        setTextAndImageWithAnimation("HISTORY", R.drawable.history);

                        handleFragment(new HomeFragment());
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }

    private void setCustomView(int selectedtab, int non1) {
        Objects.requireNonNull(tabLayout.getTabAt(selectedtab)).setCustomView(view);
        Objects.requireNonNull(tabLayout.getTabAt(non1)).setCustomView(null);

    }

    private void setTextAndImageWithAnimation(String text, int images) {
        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), android.R.anim.slide_in_left);
        animation.setInterpolator(new AccelerateDecelerateInterpolator());
        textView.setText(text);
        imageView.setImageResource(images);
        textView.startAnimation(animation);
        imageView.startAnimation(animation);
    }

    private void handleFragment(Fragment fragment) {

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
        transaction.replace(R.id.frameLayout, fragment);

        transaction.commit();
    }

    private void loadnamefirebase(int i) {
        //Toast.makeText(login.this, demcount+"THI", Toast.LENGTH_LONG).show();
            String vt = String.valueOf(i);
            // Toast.makeText(login.this,"Information/" + vt + "/mathe",Toast.LENGTH_SHORT).show();
            DatabaseReference data = FirebaseDatabase.getInstance().getReference().child("Information/" + vt + "/hoten");

            data.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                   String DB = dataSnapshot.getValue().toString();
                   txtname.setText(DB);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }

    private void loadidfirebase(int i) {
        //Toast.makeText(login.this, demcount+"THI", Toast.LENGTH_LONG).show();
        String vt = String.valueOf(i);
        // Toast.makeText(login.this,"Information/" + vt + "/mathe",Toast.LENGTH_SHORT).show();
        DatabaseReference data = FirebaseDatabase.getInstance().getReference().child("Information/" + vt + "/mathe");

        data.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String DB = dataSnapshot.getValue().toString();
                txtid.setText(DB);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


}
