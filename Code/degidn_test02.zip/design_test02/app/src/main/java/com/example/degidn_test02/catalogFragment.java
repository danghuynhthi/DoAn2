package com.example.degidn_test02;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import static android.content.Context.MODE_PRIVATE;

public class catalogFragment extends Fragment {
    TextView xnid,txtcurpass,newpass;
    Button confirm;
    String id,pass;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.catalog, container, false);
       xnid=view.findViewById(R.id.xnid);
       txtcurpass=view.findViewById(R.id.curpass);
       newpass=view.findViewById(R.id.newpass);
       confirm=view.findViewById(R.id.idbtnconfirm);

       confirm.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               loadData();
               Toast.makeText(getActivity(),id,Toast.LENGTH_SHORT).show();
               if((xnid.getText().toString().equals(id)==true) && (txtcurpass.getText().toString().equals(pass)==true))
               {
                   Toast.makeText(getActivity(),"You were change password ",Toast.LENGTH_SHORT).show();
                   saveData();
               }
               else
               {
                   Toast.makeText(getActivity(),"FAIL!",Toast.LENGTH_SHORT).show();
               }

           }
       });

        return view;

    }
    public void saveData() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("savedata", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();


        editor.putString("matkhau", newpass.getText().toString());
        editor.apply();
    }

    public void loadData() {
        SharedPreferences sharedPreferences =getActivity(). getSharedPreferences("savedata", MODE_PRIVATE);

        id = sharedPreferences.getString("id", "17119103");
        pass = sharedPreferences.getString("matkhau", "123");

    }


}
