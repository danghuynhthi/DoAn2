package com.example.degidn_test02;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class login extends AppCompatActivity {


    private EditText txtid, txtpass;
    private Button btnlogin;
    String id = "17119103", pass = "123";
    static String demcount;

    public static ArrayList<String> arrayID = new ArrayList<String>();
    String DB;
    int ghdem;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        anhxa();
        getfirebaseCount();
        new Handler().postDelayed(new Runnable() {
            public void run() {
                loadfirebase();
            }
        }, 2000);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(login.this,"i'm here" , Toast.LENGTH_LONG).show();
                if (arrayID.size() == 0)
                    loadfirebase();
                loadData();
                for (int i = 0; i < arrayID.size(); i++) {

                    if ((txtid.getText().toString().trim().equals(arrayID.get(i))==true) && (txtpass.getText().toString().trim().equals(pass)==true)) {
                        Toast.makeText(login.this, "đăng nhập thành công ", Toast.LENGTH_LONG).show();
                        Intent intent1 = new Intent(login.this, MainActivity.class);
                        intent1.putExtra("idnv", i);
                        startActivity(intent1);
                    }
                }
            }
        });
    }


    private void loadfirebase() {
        //Toast.makeText(login.this, demcount+"THI", Toast.LENGTH_LONG).show();
        // Toast.makeText(login.this,"i'm at firebase" , Toast.LENGTH_SHORT).show();
        if (demcount != null)
            ghdem = Integer.parseInt(demcount);

        for (int i = 0; i <= ghdem; i++) {

            String vt = String.valueOf(i);
            // Toast.makeText(login.this,"Information/" + vt + "/mathe",Toast.LENGTH_SHORT).show();
            DatabaseReference data = FirebaseDatabase.getInstance().getReference().child("Information/" + vt + "/mathe");

            data.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    DB = dataSnapshot.getValue().toString();
                    arrayID.add(DB);
                    Toast.makeText(login.this, "i have data", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }

    }


    private void anhxa() {
        txtid = findViewById(R.id.idid);
        txtpass = findViewById(R.id.idpass);
        btnlogin = findViewById(R.id.idbtnlogin);


    }

    private void getfirebaseCount() {

        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        DatabaseReference myRef = database.child("Counter/count");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                demcount = dataSnapshot.getValue().toString();
                // Toast.makeText(login.this,demcount+"heree",Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }

        });


    }

    public void saveData() {
        SharedPreferences sharedPreferences = getSharedPreferences("savedata", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("id", txtid.getText().toString());
        editor.putString("matkhau", txtpass.getText().toString());
        editor.apply();
    }

    public void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("savedata", MODE_PRIVATE);

        id = sharedPreferences.getString("id", "17119103");
        pass = sharedPreferences.getString("matkhau", "123");

    }
}